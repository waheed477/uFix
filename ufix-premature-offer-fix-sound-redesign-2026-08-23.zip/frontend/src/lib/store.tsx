/**
 * Store - Phase 9 Frontend Integration - REAL BACKEND CLIENT
 * 
 * This file replaces the previous mock/timer-based simulation with real API calls and Socket.io
 * 
 * Changes from mock version:
 * - No more staggered offer timers (postRequest used timers 1600,3400,5600ms) → replaced with socket.io offer:new listener
 * - No more auto-status progression (acceptOffer had timers 4500→on_the_way, 9500→arrived, 14500→in_progress) → replaced with socket job:statusUpdate listener
 * - No more chat auto-replies (sendMessage had PROVIDER_REPLIES/CUSTOMER_REPLIES + keyword detection + timers) → replaced with socket chat:send/message and REST history
 * - No more simulated SEED_REQUESTS / PROVIDERS mock data → replaced with real GET /api/requests/nearby and GET /api/jobs/history etc.
 * - All data now from real backend via api.ts client and socket.ts
 * 
 * Preserved:
 * - Same AppContext shape (stage, user, tab, screen, jobs, nearbyRequests, messages, etc.) so existing UI components (App.tsx, customer.tsx, provider.tsx, jobs.tsx, etc.) continue to work without major rewrites
 * - Visual design, screens, component structure unchanged — only data layer changed
 * 
 * JWT Storage Decision (documented for project_context.md):
 * - This is a standalone Vite app (not a claude.ai artifact), so browser storage restrictions don't apply
 * - We use localStorage for JWT persistence (TOKEN_KEY = 'ufix_jwt') so user stays logged in across refreshes
 * - Alternative memory-only would log out on refresh — worse UX for standalone app
 * - For artifact deployment, memory-only would be required, but for standalone Vite, localStorage is appropriate and documented
 * - User object also stored in localStorage (USER_KEY) for quick restore, but validated via /api/users/profile or /api/auth/me on app start
 * 
 * API Client: lib/api.ts — fetch wrapper with Bearer token, base URL from VITE_API_URL env, 401 triggers logout via custom event
 * Socket Client: lib/socket.ts — Socket.io client with JWT in auth: { token }, connect after login, disconnect on logout, central listeners
 * 
 * Backend gaps discovered and fixed (documented in project_context.md Phase 9 Backend Fixes):
 * - PATCH /api/users/profile did not accept isOnline boolean for provider online/offline toggle — added minimal fix in backend userController to allow isOnline
 * - No customer-facing "nearby providers count" endpoint — findNearbyProviders utility exists but no route exposed; we omit/hide the "pros online near you" pill with TODO rather than invent fake number (per task instruction)
 * - Other gaps: None major, all required endpoints exist
 * 
 * Error and loading states:
 * - Every real API call triggers loading skeletons via existing UI (e.g., OffersScreen shows skeletons when offers.length===0 and elapsed false — we now set loading state that triggers skeletons during real network latency)
 * - Error states show on real failures (network error, 403, 404) via toast and empty states
 */

import {
  createContext,
  useContext,
  useEffect,
  useRef,
  useState,
  useCallback,
  type ReactNode,
} from "react";
import type {
  Category,
  ChatMessage,
  IncomingRequest,
  Job,
  JobStatus,
  Offer,
  Role,
  SentOffer,
  SentOfferStatus,
  User,
  GeoPoint,
} from "./types";
import {
  DEFAULT_ADDRESS,
  DEFAULT_CITY,
  DEFAULT_COORDS,
  DEFAULT_REGION,
  getPosition,
  reverseGeocode,
  type Coords,
  coordsToOffset,
  offsetToCoords,
  getCityCoords,
  getCityByName,
  findNearestCity,
  PAKISTAN_CITIES,
} from "./location";
import { api, getToken, setToken, setStoredUser, getStoredUser, clearAuth, setAuthSession, getRefreshToken } from "./api";
import { socketClient } from "./socket";
import { playNotificationTone, playNewRequestTone, playBookingConfirmedTone, vibrateAlert } from "./sound";
import { reconcileNearbyRequests } from "./listReconcile";
import {
  adaptBackendUserToFrontendUser,
  adaptBackendRequestToFrontendJob,
  adaptBackendOfferToFrontendOffer,
  adaptBackendJobToFrontendJob,
  adaptBackendMessageToFrontendMessage,
  adaptBackendRequestToIncomingRequest,
  adaptBackendNotificationToFrontend,
  toTimestamp,
  lngLatToXY,
} from "./adapters";

export type Stage = "splash" | "auth" | "providerSetup" | "location" | "app";
export type Tab = "home" | "jobs" | "chat" | "profile";
export type LocStatus = "idle" | "requesting" | "granted" | "denied";

export interface Loc {
  status: LocStatus;
  coords: Coords | null;
  address: string;
  city: string;
  region: string;
  accuracy: number | null;
  custom: boolean;
}
export type Screen =
  | "newRequest"
  | "offers"
  | "availableProviders"
  | "activeJob"
  | "chat"
  | "rating"
  | "history"
  | "editProfile"
  | "soundPreview"; // TEMP dev-only (SoundPreview panel) — remove from production

interface Toast {
  msg: string;
  icon: "check" | "send" | "info";
}

interface AppContextValue {
  stage: Stage;
  setStage: (s: Stage) => void;
  user: User | null;
  tab: Tab;
  screen: Screen | null;
  jobs: Job[];
  nearbyRequests: IncomingRequest[];
  messages: Record<string, ChatMessage[]>;
  activeRequestId: string | null;
  activeJobId: string | null;
  activeJob: Job | null;
  toast: Toast | null;
  draftCategory: Category;
  setDraftCategory: (c: Category) => void;

  // location
  location: Loc;
  gps: Loc | null;
  requestLocation: () => void;
  skipLocation: () => void;
  searchLocation: (p: { coords: Coords; label: string; city: string; region: string }) => void;
  resetLocation: () => void;
  setLocationFromCity: (cityName: string) => boolean;

  // auth - real backend
  completeAuth: (role: Role, name: string, phone: string, city?: string) => void; // kept for compatibility, but now does real logic via login
  completeProviderSetup: (category: Category, radiusKm: number) => void;
  updateProfile: (name: string, city?: string) => void;
  uploadProfilePicture: (file: File) => Promise<string | null>;
  toggleOnline: () => void;
  logout: () => void;

  // navigation
  setTab: (t: Tab) => void;
  navigate: (s: Screen) => void;
  back: () => void;

  // customer actions - real backend
  postRequest: (category: Category, description: string, location: GeoPoint, address: string) => void;
  acceptOffer: (jobId: string, offer: Offer) => void;
  declineOffer: (jobId: string, offerId: string) => void;
  withdrawOffer: (offerId: string) => Promise<boolean>;
  cancelRequest: (jobId: string) => void;
  directBookRequest: (requestId: string, providerId: string) => Promise<boolean>;
  openActiveJob: () => Promise<boolean>;
  openJobRating: (jobId: string) => void;
  dismissMyOffer: (offerId: string) => void;
  completeJob: (jobId: string, rating: number, review: string) => void;

  // provider actions - real backend
  sendOffer: (requestId: string, charge: number) => void;
  updateJobStatus: (jobId: string, status: JobStatus) => void;

  // chat - real backend via socket
  openChat: (jobId: string) => void;
  markRead: (jobId: string, senderId: string) => void;
  sendMessage: (jobId: string, text: string, peer: { id: string; isProvider: boolean }) => void;

  // new for Bidirectional Sync pass - provider's own sent offers with live fate badges
  myOffers: SentOffer[];

  // Availability & Expiry pass - true while the provider has an active job (busy):
  // nearby request cards are hidden + offers blocked (mirrors backend enforcement)
  providerBusy: boolean;
  /** Live "X providers viewing your request" counts per open request id (2026-08-21 Issue 2).
      Fed by POST /requests response + request:viewCount socket (creation + provider online/offline). */
  viewCounts: Record<string, { count: number; category: string }>;

  // new for Phase 9 - exposed for screens that need real data
  notifications: any[];
  unreadCount: number;
  notificationsLoading: boolean;
  loadNotifications: () => Promise<void>;
  markNotificationRead: (id: string) => Promise<void>;
  markAllNotificationsRead: () => Promise<void>;
  refreshNearbyRequests: () => Promise<void>;
  refreshJobs: () => Promise<void>;
  isLoading: Record<string, boolean>;
}

const AppContext = createContext<AppContextValue | null>(null);

let toastTimer: number | null = null;

export function AppProvider({ children }: { children: ReactNode }) {
  const [stage, setStage] = useState<Stage>("splash");
  const [user, setUser] = useState<User | null>(null);
  const [tab, setTabState] = useState<Tab>("home");
  const [stack, setStack] = useState<Screen[]>([]);

  const [jobs, setJobs] = useState<Job[]>([]);
  const [nearbyRequests, setNearbyRequests] = useState<IncomingRequest[]>([]);
  const [messages, setMessages] = useState<Record<string, ChatMessage[]>>({});
  const [activeRequestId, setActiveRequestId] = useState<string | null>(null);
  const [activeJobId, setActiveJobId] = useState<string | null>(null);
  const [toast, setToast] = useState<Toast | null>(null);
  const [draftCategory, setDraftCategory] = useState<Category>("plumber");
  const [location, setLocation] = useState<Loc>({
    status: "idle",
    coords: DEFAULT_COORDS,
    address: DEFAULT_ADDRESS,
    city: DEFAULT_CITY,
    region: DEFAULT_REGION,
    accuracy: null,
    custom: false,
  });
  const [gps, setGps] = useState<Loc | null>(null);
  const [notifications, setNotifications] = useState<any[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [notificationsLoading, setNotificationsLoading] = useState(false);
  const [isLoading, setIsLoading] = useState<Record<string, boolean>>({});

  // Bidirectional Sync pass: provider-side tracking of offers THEY sent.
  // Persisted to localStorage so the "Your offers" activity view survives refresh.
  // Fate is updated live by socket events: offer:accepted / offer:declined / offer:rejected / request:cancelled.
  const MY_OFFERS_KEY = 'ufix_my_offers';
  const [myOffers, setMyOffers] = useState<SentOffer[]>(() => {
    try {
      const raw = localStorage.getItem(MY_OFFERS_KEY);
      if (!raw) return [];
      const parsed = JSON.parse(raw);
      return Array.isArray(parsed) ? parsed.slice(0, 30) : [];
    } catch {
      return [];
    }
  });
  useEffect(() => {
    try {
      localStorage.setItem(MY_OFFERS_KEY, JSON.stringify(myOffers.slice(0, 30)));
    } catch {}
  }, [myOffers]);

  // Availability & Expiry pass: busy = provider currently has an active (non-completed) job.
  // While busy, the backend returns zero nearby requests (hasActiveJob) and rejects new offers;
  // this flag drives the calm banner + hides request cards client-side as well.
  const [providerBusy, setProviderBusy] = useState(false);
  const [viewCounts, setViewCounts] = useState<Record<string, { count: number; category: string }>>({});

  /** Mark sent offers' fate. Pass offerId or requestId matcher. */
  const markMyOffers = useCallback((matcher: { offerId?: string; requestId?: string }, status: SentOfferStatus) => {
    if (!matcher.offerId && !matcher.requestId) return;
    setMyOffers(prev => {
      let changed = false;
      const next = prev.map(o => {
        const hit = matcher.offerId
          ? o.id === matcher.offerId
          : o.requestId === matcher.requestId && o.status === 'pending';
        if (hit && o.status !== status) {
          changed = true;
          return { ...o, status };
        }
        return o;
      });
      return changed ? next : prev;
    });
  }, []);

  const isMountedRef = useRef(true);

  // Toast helper
  const showToast = useCallback((msg: string, icon: Toast["icon"] = "info") => {
    setToast({ msg, icon });
    if (toastTimer) window.clearTimeout(toastTimer);
    toastTimer = window.setTimeout(() => setToast(null), 2600);
  }, []);

  const setLoading = useCallback((key: string, loading: boolean) => {
    setIsLoading(prev => ({ ...prev, [key]: loading }));
  }, []);

  // Persist activeRequestId to survive refresh - critical for Offers screen polling
  const ACTIVE_REQUEST_KEY = 'ufix_active_request_id';
  const persistActiveRequestId = useCallback((id: string | null) => {
    try {
      if (id) {
        localStorage.setItem(ACTIVE_REQUEST_KEY, id);
        console.log(`[Store] Persisted activeRequestId: ${id}`);
      } else {
        localStorage.removeItem(ACTIVE_REQUEST_KEY);
        console.log('[Store] Cleared activeRequestId');
      }
    } catch {}
  }, []);

  const getPersistedActiveRequestId = useCallback(() => {
    try {
      return localStorage.getItem(ACTIVE_REQUEST_KEY);
    } catch {
      return null;
    }
  }, []);

  // --- Auth restoration on mount ---
  useEffect(() => {
    isMountedRef.current = true;

    // Splash auto-advance
    const splashTimer = setTimeout(() => {
      const token = getToken();
      const storedUser = getStoredUser();

      if (token && storedUser) {
        // Try to restore session via real API
        (async () => {
          try {
            setLoading('auth', true);
            // Session restore = GET /auth/me (2026-08-21): validates the access token
            // (apiFetch silently refreshes it via the refresh token if expired) and returns
            // the backend-computed setupComplete flag we route on. isNewUser:false always.
            const meData = await api.auth.me();
            const backendUser = meData.user;
            setStoredUser(backendUser); // refresh the cached profile incl. setup flags
            const frontendUser = adaptBackendUserToFrontendUser(backendUser);
            
            if (isMountedRef.current) {
              setUser(frontendUser);
              // Connect socket with existing token
              socketClient.connect();

              // Post-Audit Fix P2: the BACKEND is the source of truth for location on restore.
              // Previously this block reset the location to the city CENTER on every reload and
              // PATCHed it back - destroying any precise GPS/dragged location - and the stale
              // 'idle' closure then forced the LocationPermissionScreen on EVERY session.
              const savedCoords = (backendUser as any).location?.coordinates as number[] | undefined;
              const hasRealLocation =
                Array.isArray(savedCoords) &&
                savedCoords.length === 2 &&
                !(savedCoords[0] === 0 && savedCoords[1] === 0);
              if (hasRealLocation) {
                const [slng, slat] = savedCoords!;
                const cityName = (backendUser.city as string | undefined) || findNearestCity({ lat: slat, lng: slng })?.name;
                const cityInfo = cityName ? getCityByName(cityName) : null;
                setLocation({
                  status: 'granted',
                  coords: { lat: slat, lng: slng },
                  address: cityInfo ? `${cityInfo.name}, ${cityInfo.region}` : (backendUser.city || DEFAULT_ADDRESS),
                  city: cityInfo?.name || backendUser.city || DEFAULT_CITY,
                  region: cityInfo?.region || DEFAULT_REGION,
                  accuracy: null,
                  custom: true,
                });
                console.log(`[Auth Restore] Trusted backend location [${slng},${slat}] city=${cityName || 'unknown'} - no overwrite`);
                // NOTE: intentionally NO PATCH here - backend already holds this location.
              } else if (backendUser.city) {
                // No saved location yet (new user): pre-center the map on their city in STATE
                // only (no backend write) - they still need to set a real location.
                const cityCoords = getCityCoords(backendUser.city);
                if (cityCoords) {
                  const cityInfo = getCityByName(backendUser.city);
                  setLocation({
                    status: 'granted',
                    coords: cityCoords,
                    address: cityInfo ? `${cityInfo.name}, ${cityInfo.region}` : backendUser.city,
                    city: cityInfo?.name || backendUser.city,
                    region: cityInfo?.region || DEFAULT_REGION,
                    accuracy: null,
                    custom: true,
                  });
                  console.log(`[Auth Restore] No saved location - pre-centering on city ${backendUser.city} (state only)`);
                }
              }

              // Stage decision STRICTLY from the backend's setupComplete (2026-08-21):
              // complete => app (location saved) or location permission (none saved);
              // incomplete provider => provider wizard at the exact resume step.
              if (backendUser.setupComplete === false && frontendUser.role === 'provider') {
                try { localStorage.setItem('ufix_setup_resume_step', backendUser.setupStep === 'verification' ? '2' : '0'); } catch {}
                setStage('providerSetup');
              } else if (hasRealLocation) {
                setStage('app');
              } else {
                setStage('location');
              }
            }
          } catch (err) {
            console.warn('Failed to restore session, going to auth', err);
            clearAuth();
            socketClient.disconnect();
            if (isMountedRef.current) {
              setStage('auth');
            }
          } finally {
            setLoading('auth', false);
          }
        })();
      } else {
        // No token, go to auth
        if (isMountedRef.current) {
          setStage('auth');
        }
      }
    }, 2000);

    // Listen for 401 unauthorized event from api.ts
    const handleUnauthorized = (e: any) => {
      console.log('Received unauthorized event, logging out');
      // Only reachable when the silent refresh also failed (api.ts) - tell the user why.
      showToast('Session expired, please log in again.', 'info');
      handleLogout();
    };

    window.addEventListener('ufix:unauthorized' as any, handleUnauthorized);

    return () => {
      isMountedRef.current = false;
      clearTimeout(splashTimer);
      window.removeEventListener('ufix:unauthorized' as any, handleUnauthorized);
      if (toastTimer) clearTimeout(toastTimer);
    };
  }, []);

  // --- Socket listeners setup ---
  useEffect(() => {
    if (stage !== 'app' || !user) return;

    // Ensure socket connected
    socketClient.connect();

    // Request:new → provider gets new nearby request
    const offRequestNew = socketClient.on('request:new', (data: any) => {
      console.log('[Store] Received request:new', data);
      try {
        const backendRequest = data.request;
        if (!backendRequest) return;

        // Only for providers
        if (user.role !== 'provider') return;

        // Availability lock: a busy provider (active job) never acts on new requests.
        // The backend already excludes them from the fan-out; this is a client-side guard
        // for events that arrived just before the job was accepted (belt-and-suspenders).
        if (providerBusy) {
          console.log('[Store] request:new ignored - provider busy with active job');
          return;
        }

        // Adapt to IncomingRequest
        const incoming = adaptBackendRequestToIncomingRequest(backendRequest, { baseCoords: location.coords || DEFAULT_COORDS });
        
        setNearbyRequests(prev => {
          // Avoid duplicates
          if (prev.some(r => r.id === incoming.id)) return prev;
          return [incoming, ...prev];
        });

        // BUG 2 FIX: Play sound + vibration for provider when new matching request arrives
        // This must happen WITHOUT requiring manual refresh - card appears via setNearbyRequests above
        // (sound/vibration implementation deduplicated into lib/sound.ts - shared with other live events)
        // New-request alert tone, id-deduped with the poll sentinel in provider.tsx (sound system).
        playNewRequestTone(String(backendRequest.id ?? backendRequest._id ?? ''));

        showToast(`New ${backendRequest.category} request in ${backendRequest.city || 'your city'} nearby`, 'info');
      } catch (e) {
        console.error('Failed to handle request:new', e);
      }
    });
    // request:viewCount → customer (2026-08-21, Issue 2): "X providers viewing your request"
    // live indicator. Emitted at request creation and re-emitted on provider online/offline
    // transitions; count = matching (online+verified+radius, non-busy) providers.
    const offRequestViewCount = socketClient.on('request:viewCount', (data: any) => {
      try {
        const rid = (data?.requestId ?? data?.request?.id)?.toString();
        if (!rid) return;
        setViewCounts(prev => ({ ...prev, [rid]: { count: Number(data.count) || 0, category: data.category || prev[rid]?.category } }));
      } catch (e) { console.error('Failed to handle request:viewCount', e); }
    });


    // Offer:new → customer gets new offer
    const offOfferNew = socketClient.on('offer:new', (data: any) => {
      console.log('[Store] Received offer:new', data);
      try {
        const offerData = data.offer || data;
        const adaptedOffer = data.frontend || adaptBackendOfferToFrontendOffer(offerData, { category: offerData.request?.category || draftCategory });

        // Find which job/request this offer belongs to
        const requestId = offerData.request?.id || offerData.request?.toString() || adaptedOffer.id;

        setJobs(prev => prev.map(job => {
          // For customer, job id is request id (since request maps to job with status open)
          // The offer is for a specific request, so we need to find job with id == requestId
          if (job.id === requestId || job.id === (offerData.request?.id)) {
            const existingOffers = job.offers || [];
            // Avoid duplicate
            if (existingOffers.some(o => o.id === adaptedOffer.id)) return job;
            return { ...job, offers: [...existingOffers, adaptedOffer] };
          }
          return job;
        }));

        showToast(`New offer from ${adaptedOffer.providerName}`, 'info');
      } catch (e) {
        console.error('Failed to handle offer:new', e);
      }
    });

    // Offer:accepted → provider gets accepted
    const offOfferAccepted = socketClient.on('offer:accepted', (data: any) => {
      console.log('[Store] Received offer:accepted', data);
      (async () => {
        try {
          const requestId = data.request?.id || data.requestId;

          // Bidirectional Sync: mark this provider's own sent offer as accepted + celebratory feedback
          if (data.offer?.id) markMyOffers({ offerId: data.offer.id.toString() }, 'accepted');
          // Booking confirmation tone (customer + provider); offerId dedups the accept-action path below.
          playBookingConfirmedTone(data.offer?.id != null ? String(data.offer.id) : undefined);

          // Availability lock: this handler also fires for customers - only the PROVIDER
          // whose offer was accepted becomes busy (their job room gets this same event)
          if (user.role === 'provider' && data.offer?.id) {
            setProviderBusy(true);
            setNearbyRequests([]);
          }

          showToast(data.message || 'Your offer was accepted! 🎉', 'check');

          // Refresh jobs to get new active job
          await refreshJobs();

          // Try to fetch active job directly and auto-navigate to activeJob screen for provider
          try {
            const activeData = await api.jobs.myActive();
            if (activeData.job) {
              const frontendJob = adaptBackendJobToFrontendJob(activeData.job, { baseCoords: location.coords || DEFAULT_COORDS });
              // Update jobs list with active job if not present
              setJobs(prev => {
                const exists = prev.find(j => j.id === frontendJob.id);
                if (exists) {
                  return prev.map(j => j.id === frontendJob.id ? frontendJob : j);
                }
                return [frontendJob, ...prev];
              });
              setActiveJobId(frontendJob.id);
              setStack(['activeJob']);
              setTabState('jobs');
            }
          } catch (e) {
            console.log('No active job yet after accept, will rely on refreshJobs', e);
          }

          refreshNearbyRequests();
        } catch (e) {
          console.error('Failed to handle offer:accepted', e);
        }
      })();
    });

    // Offer:rejected → provider's offer was not selected (customer accepted someone else's)
    // Bidirectional Sync: update provider's own offer card to "Not selected" badge, live.
    const offOfferRejected = socketClient.on('offer:rejected', (data: any) => {
      console.log('[Store] Received offer:rejected', data);
      if (data.offerId) markMyOffers({ offerId: data.offerId.toString() }, 'rejected');
      if (data.requestId) markMyOffers({ requestId: data.requestId.toString() }, 'rejected');
      showToast(data.message || 'Your offer was not selected', 'info');
    });

    // Offer:declined (NEW) → customer explicitly declined THIS provider's offer
    // Provider gets: live "Declined" badge on their offer card + toast (notification persisted by backend)
    const offOfferDeclined = socketClient.on('offer:declined', (data: any) => {
      console.log('[Store] Received offer:declined', data);
      if (data.offerId) markMyOffers({ offerId: data.offerId.toString() }, 'declined');
      vibrateAlert('negative'); // ping standardized via persisted offer_declined notification
      showToast('Customer declined your offer — you can send a revised one', 'info');
    });

    // Offer:withdrawn -> customer: a provider pulled their offer back (2026-08-21).
    // Remove it from any open request's offers so the customer never sees a dead offer;
    // the 2s OffersScreen poll also filters non-pending (belt-and-suspenders).
    // Provider (multi-device): no-op beyond the PATCH-response badge update.
    const offOfferWithdrawn = socketClient.on('offer:withdrawn', (data: any) => {
      console.log('[Store] Received offer:withdrawn', data);
      const withdrawnOfferId = data.offerId?.toString();
      if (withdrawnOfferId) {
        setJobs(prev => prev.map(j => (j.offers ? { ...j, offers: j.offers.filter((o: any) => o.id !== withdrawnOfferId) } : j)));
        markMyOffers({ offerId: withdrawnOfferId }, 'withdrawn');
      }
      showToast('A provider withdrew their offer', 'info');
    });

    // Request:closed → provider, request no longer available
    const offRequestClosed = socketClient.on('request:closed', (data: any) => {
      console.log('[Store] Received request:closed', data);
      const closedRequestId = data.requestId;
      setNearbyRequests(prev => prev.filter(r => r.id !== closedRequestId));
      showToast('Request no longer available', 'info');
    });

    // Request:cancelled → provider, request cancelled by customer
    // Bidirectional Sync: any pending offer THIS provider sent on it gets a "Cancelled" badge (not silently dropped)
    const offRequestCancelled = socketClient.on('request:cancelled', (data: any) => {
      console.log('[Store] Received request:cancelled', data);
      const cancelledId = data.requestId;
      if (cancelledId) setViewCounts(prev => { const next = { ...prev }; delete next[cancelledId.toString()]; return next; });
      setNearbyRequests(prev => prev.filter(r => r.id !== cancelledId));
      if (cancelledId) markMyOffers({ requestId: cancelledId.toString() }, 'cancelled');
      showToast('Request cancelled by customer', 'info');
    });

    // Request:expired (Availability & Expiry pass) → customer whose request expired, and
    // providers who offered on it. Lazy backend flips it; this updates cards/badges live.
    const offRequestExpired = socketClient.on('request:expired', (data: any) => {
      console.log('[Store] Received request:expired', data);
      const expiredId = data.requestId?.toString();
      if (!expiredId) return;
      setViewCounts(prev => { const next = { ...prev }; delete next[expiredId]; return next; });

      if (user.role === 'customer') {
        // Flip their own request to cancelled-with-reason so Jobs/History show "Expired"
        setJobs(prev => prev.map(j => j.id === expiredId ? { ...j, status: 'cancelled' as any, cancelledReason: 'expired' } : j));
        // If they were waiting on offers for it, the offers screen falls back to the Expired state
        setActiveRequestId(prev => {
          if (prev === expiredId) {
            persistActiveRequestId(null);
            return null;
          }
          return prev;
        });
        showToast('Your request expired — no providers responded in time', 'info');
      } else {
        // Provider: drop the card + flip their offer badge to "Request expired"
        setNearbyRequests(prev => prev.filter(r => r.id !== expiredId));
        markMyOffers({ requestId: expiredId }, 'expired');
        showToast('A request you offered on expired', 'info');
      }
    });

    // Job:statusUpdate → both customer and provider
    const offJobStatusUpdate = socketClient.on('job:statusUpdate', (data: any) => {
      console.log('[Store] Received job:statusUpdate', data);
      try {
        const jobId = (data.jobId || data.job?.id)?.toString();
        const newStatus = data.newStatus;

        if (!jobId || !newStatus) return;

        setJobs(prev => prev.map(j => {
          if (j.id === jobId) {
            return { ...j, status: newStatus as any };
          }
          return j;
        }));

        // Update activeJob if it's the same
        // Note: activeJob is derived from jobs + activeJobId, so we need to update jobs and let activeJob effect handle it
        // Also show toast
        showToast(`Job status: ${newStatus.replace('_', ' ')}`, 'check');

        // Bidirectional Sync (Part B): job COMPLETED is a first-class moment on BOTH sides -
        // prominent feedback + automatic transition into the Rating screen (no digging required):
        // - Customer: "Your job is complete!" → rate the provider
        // - Provider: confirmation on their side too → rate the customer (Phase 8 supports both directions)
        if (newStatus === 'completed') {
          vibrateAlert('positive'); // ping via persisted notif
          // Availability lock released: provider is free to receive new matches again
          if (user.role === 'provider') setProviderBusy(false);
          setActiveJobId(jobId);
          if (user.role === 'customer') {
            showToast('Your job is complete! 🎉 Please rate your experience', 'check');
          } else {
            showToast('Job completed! 🎉 Rate your customer', 'check');
          }
          setTabState('jobs');
          setStack(['rating']);
        }
      } catch (e) {
        console.error('Failed to handle job:statusUpdate', e);
      }
    });

    // Chat:message → both participants
    const offChatMessage = socketClient.on('chat:message', (data: any) => {
      console.log('[Store] Received chat:message', data);
      try {
        const messageData = data.message;
        if (!messageData) return;

        const jobId = data._backend?.job || messageData._backend?.job || messageData.job;
        // messageData should have id, senderId, text, timestamp, read, senderName etc
        // Adapt to ChatMessage if needed
        const chatMessage: ChatMessage = {
          id: messageData.id || messageData._id,
          senderId: messageData.senderId || messageData.sender,
          text: messageData.text,
          timestamp: messageData.timestamp || toTimestamp(messageData.createdAt),
          read: !!messageData.read,
        };

        // Determine jobId - if not in payload, try to infer from message's job
        const targetJobId = jobId || messageData._backend?.job || (messageData as any).jobId;
        if (!targetJobId) {
          console.warn('chat:message missing jobId, cannot add to messages');
          return;
        }

        const targetJobIdStr = targetJobId.toString();

        setMessages(prev => {
          const existing = prev[targetJobIdStr] || [];
          // Avoid duplicates
          if (existing.some(m => m.id === chatMessage.id)) return prev;
          return {
            ...prev,
            [targetJobIdStr]: [...existing, chatMessage],
          };
        });
      } catch (e) {
        console.error('Failed to handle chat:message', e);
      }
    });

    // Chat:read → other participant read receipt
    const offChatRead = socketClient.on('chat:read', (data: any) => {
      console.log('[Store] Received chat:read', data);
      try {
        const { jobId, readByUserId } = data;
        if (!jobId || !readByUserId) return;

        setMessages(prev => {
          const existing = prev[jobId] || [];
          if (existing.length === 0) return prev;

          // Mark messages sent by current user? Actually read receipt means other party read my messages
          // So we should mark messages where senderId === "me" or senderId === current user id as read
          // Since our senderId is real user id or "me" mapped, we need to handle both
          // For simplicity, mark all messages where senderId !== readByUserId as read? Actually readByUserId is who read, so messages sent by me that were read by other party should be marked read
          // Let's mark messages where senderId is "me" or senderId is current user's id as read when we receive read receipt from other party
          const currentUserId = user.id;
          const isSelfRead = data.isSelf;

          if (isSelfRead) {
            // This is confirmation that we marked other's messages as read, no need to update our sent messages read status
            // Actually for our own UI, we don't need to do anything for self confirmation
            return prev;
          }

          // Other party read my messages
          return {
            ...prev,
            [jobId]: existing.map(m => {
              // If message sender is me (or current user id) and currently unread, mark as read
              const isMyMessage = m.senderId === 'me' || m.senderId === currentUserId;
              if (isMyMessage && !m.read) {
                return { ...m, read: true };
              }
              return m;
            }),
          };
        });
      } catch (e) {
        console.error('Failed to handle chat:read', e);
      }
    });

    // Chat:error
    const offChatError = socketClient.on('chat:error', (data: any) => {
      console.error('[Store] chat:error', data);
      showToast(data.message || 'Chat error', 'info');
    });

    // Notification:new → bell badge
    const offNotificationNew = socketClient.on('notification:new', (data: any) => {
      console.log('[Store] Received notification:new', data);
      try {
        const notification = data.notification;
        if (!notification) return;

        const adapted = adaptBackendNotificationToFrontend(notification);

        setNotifications(prev => {
          // Avoid duplicates
          if (prev.some(n => n.id === adapted.id)) return prev;
          return [adapted, ...prev];
        });
        setUnreadCount(prev => prev + 1);

        // Standardized general ping for ALL persisted notifications - EXCEPT types that own a
        // dedicated tone: offer_accepted (booking tone) and request_new (ID-tracked request alert;
        // no longer persisted since 2026-08-21). See sound.ts for tone definitions.
        const ntype = (data.notification as any)?.type;
        if (ntype !== 'offer_accepted' && ntype !== 'request_new') {
          playNotificationTone(String((data.notification as any)?.id ?? (data.notification as any)?._id ?? adapted.id ?? ''));
        }

        showToast(notification.title || 'New notification', 'info');
      } catch (e) {
        console.error('Failed to handle notification:new', e);
      }
    });

    return () => {
      offRequestNew();
      offRequestViewCount();
      offOfferNew();
      offOfferAccepted();
      offOfferRejected();
      offOfferDeclined();
      offOfferWithdrawn();
      offRequestClosed();
      offRequestCancelled();
      offRequestExpired();
      offJobStatusUpdate();
      offChatMessage();
      offChatRead();
      offChatError();
      offNotificationNew();
    };
  }, [stage, user, draftCategory, location.coords, markMyOffers, providerBusy]);

  // Helper for timestamp
  function toTimestamp(date: any): number {
    if (!date) return Date.now();
    if (typeof date === 'number') return date;
    return new Date(date).getTime();
  }

  // --- Location handling ---
  // FIXED: Ensure backend always gets a valid location even when GPS denied or skipped
  // Previously, denied/skip path did NOT call PATCH /api/users/location, so DB stayed at [0,0]
  // which caused findNearbyProviders and findNearbyRequests to return empty (provider live request bug)
  const requestLocation = useCallback(async () => {
    setLocation(l => ({ ...l, status: 'requesting' }));
    try {
      const { coords, accuracy } = await getPosition();
      let addr = { address: DEFAULT_ADDRESS, city: DEFAULT_CITY, region: DEFAULT_REGION };
      try {
        const { address, city, region } = await reverseGeocode(coords.lat, coords.lng);
        addr = { address, city, region };
      } catch {}
      
      // Post-Audit Fix P3 (consistency): the MATCHING layer filters on the Pakistan-cities
      // vocabulary (e.g. "Lahore"). Nominatim can return values like "Lahore District" or a
      // suburb name - those would silently break city matching. Canonicalize the city to the
      // NEAREST city in our DB while keeping the geocoded address as the display label.
      const nearestCity = findNearestCity(coords);
      const canonicalCity = nearestCity?.name || addr.city;
      const canonicalRegion = nearestCity?.region || addr.region;

      // Regression Fix (BUG A - 2026-08-20): EXPLICIT USER SELECTION ALWAYS WINS over GPS.
      // Root cause: this granted branch UNCONDITIONALLY canonicalized the GPS city and
      // $set user.city + PATCHed the backend. Combined with the 700ms auto-prompt
      // (Post-Audit Decision 6), a user who picked e.g. "Faisalabad" at onboarding was
      // SILENTLY switched to whatever reverse-geocoding resolved ("Multan"/"Khanewal
      // District" - which also happens when a VPN/emulator reports proxied coordinates).
      // Chosen option (a) - simplest, no confirm prompt UI: if an explicit city exists
      // (picked at onboarding / PlaceSearch / Profile edit, or restored as the user's
      // stored city), GPS may refine the pin ONLY when it canonicalizes to the SAME
      // city. A conflicting GPS reading is ignored for location purposes: the explicit
      // city stays and the backend is reconciled to it. To change cities, the user uses
      // Profile or PlaceSearch again (explicit by design).
      const explicitCity =
        user?.city || getStoredUser()?.city || (location.custom ? location.city : undefined);
      if (explicitCity && canonicalCity && explicitCity !== canonicalCity) {
        console.log(
          `[Location] GPS resolved to "${canonicalCity}" but "${explicitCity}" was explicitly selected - keeping explicit selection (no silent override)`
        );
        // Never keep the conflicting reading as the gps fallback either - resetLocation()
        // re-applies `gps`, which would otherwise re-trigger the override.
        setGps(null);
        const ei = getCityByName(explicitCity);
        // P2 doctrine: never clobber a precise saved pin - reuse the backend's stored
        // pin when it still canonicalizes to the explicit city; else use the city center.
        const stored = getStoredUser();
        const savedCoords = (stored as any)?.location?.coordinates as number[] | undefined;
        const savedPinMatches =
          !!ei &&
          Array.isArray(savedCoords) &&
          savedCoords.length === 2 &&
          !(savedCoords[0] === 0 && savedCoords[1] === 0) &&
          findNearestCity({ lng: savedCoords[0], lat: savedCoords[1] })?.name === ei.name;
        const keepCoords =
          ei && savedPinMatches
            ? ({ lng: savedCoords![0], lat: savedCoords![1] } as Coords)
            : ei
              ? getCityCoords(ei.name)
              : null;
        if (ei && keepCoords) {
          setLocation({
            status: 'granted',
            coords: keepCoords,
            address: `${ei.name}, ${ei.region}`,
            city: ei.name,
            region: ei.region,
            accuracy: null,
            custom: true,
          });
          // Reconcile the backend ONLY when it is desynced from the explicit city
          // (repairs records poisoned by the old silent-override; idempotent; leaves
          // healthy precise pins untouched).
          if (!savedPinMatches) {
            try {
              await api.users.updateLocation(keepCoords.lng, keepCoords.lat, ei.name);
              console.log(`[Location] Reconciled backend with explicit city "${ei.name}"`);
            } catch (e) {
              console.warn('[Location] Failed to reconcile backend with explicit city', e);
            }
          }
        }
        if (user?.role === 'provider') showToast("You're live — ready to receive requests!", 'check');
        return;
      }

      const next: Loc = {
        status: 'granted',
        coords,
        address: addr.address,
        city: canonicalCity,
        region: canonicalRegion,
        accuracy,
        custom: false,
      };
      setGps(next);
      setLocation(next);
      // Keep the user record's city in sync with the detected real city
      if (user && canonicalCity && user.city !== canonicalCity) {
        setUser(prev => prev ? { ...prev, city: canonicalCity } : prev);
        const stored = getStoredUser();
        if (stored) setStoredUser({ ...stored, city: canonicalCity });
      }

      // Also send to backend for geospatial queries (Phase 3 + Phase 9).
      // Post-Audit Fix P3: send the reverse-geocoded city in the SAME call so DB
      // user.city and stored coordinates never represent different places.
      try {
        await api.users.updateLocation(coords.lng, coords.lat, canonicalCity);
        console.log('[Location] Updated backend with lng,lat,city', coords.lng, coords.lat, canonicalCity);
      } catch (e) {
        console.warn('[Location] Failed to update backend location', e);
      }

      if (user?.role === 'provider') showToast("You're live — ready to receive requests!", 'check');
    } catch {
      // Post-Audit Fix P1: GPS denied/timed out -> fall back to the coordinates of the
      // user's ALREADY-SELECTED city (Pakistan cities DB), NOT the hardcoded
      // DEFAULT_COORDS (Faisalabad). Previously this clobbered e.g. a Lahore user's
      // location both in state AND in the backend, desyncing DB city from stored coords.
      const fallbackCityName = user?.city || location.city;
      const cityCoords = fallbackCityName ? getCityCoords(fallbackCityName) : null;
      const cityInfo = fallbackCityName ? getCityByName(fallbackCityName) : null;
      const fallback = cityCoords && cityInfo
        ? { coords: cityCoords, address: `${cityInfo.name}, ${cityInfo.region}`, city: cityInfo.name, region: cityInfo.region }
        : { coords: DEFAULT_COORDS, address: DEFAULT_ADDRESS, city: DEFAULT_CITY, region: DEFAULT_REGION };
      setGps(null);
      setLocation({
        status: 'denied',
        coords: fallback.coords,
        address: fallback.address,
        city: fallback.city,
        region: fallback.region,
        accuracy: null,
        custom: false,
      });

      try {
        await api.users.updateLocation(fallback.coords.lng, fallback.coords.lat, fallback.city);
        console.log(`[Location] GPS denied - fell back to selected city "${fallback.city}" coords`, fallback.coords);
      } catch (e) {
        console.warn('[Location] Failed to set fallback backend location', e);
      }
    } finally {
      setStage(s => (s === 'location' ? 'app' : s));
    }
  }, [user, location.city, location.custom, showToast]);

  const skipLocation = useCallback(() => {
    // Post-Audit Fix P1: "skip" means "use my selected city" - NOT hardcoded Faisalabad.
    const fallbackCityName = user?.city || location.city;
    const cityCoords = fallbackCityName ? getCityCoords(fallbackCityName) : null;
    const cityInfo = fallbackCityName ? getCityByName(fallbackCityName) : null;
    const fallback = cityCoords && cityInfo
      ? { coords: cityCoords, address: `${cityInfo.name}, ${cityInfo.region}`, city: cityInfo.name, region: cityInfo.region }
      : { coords: DEFAULT_COORDS, address: DEFAULT_ADDRESS, city: DEFAULT_CITY, region: DEFAULT_REGION };
    setLocation({
      status: 'denied',
      coords: fallback.coords,
      address: fallback.address,
      city: fallback.city,
      region: fallback.region,
      accuracy: null,
      custom: false,
    });
    api.users.updateLocation(fallback.coords.lng, fallback.coords.lat, fallback.city)
      .then(() => console.log(`[Location] Skipped - set backend to selected city "${fallback.city}" coords`))
      .catch(e => console.warn('[Location] Failed to set fallback on skip', e));
    setStage('app');
  }, [user, location.city]);

  const searchLocation = useCallback((p: { coords: Coords; label: string; city: string; region: string }) => {
    const newLoc: Loc = {
      status: 'granted',
      coords: p.coords,
      address: p.label,
      city: p.city || DEFAULT_CITY,
      region: p.region || DEFAULT_REGION,
      accuracy: null,
      custom: true,
    };
    setLocation(newLoc);

    // Post-Audit Fix P3: keep the user record's city in sync too (UI, asks, toasts) and send
    // coords+city in ONE atomic PATCH (backend updates both fields with a single $set).
    setUser(prev => (prev ? { ...prev, city: newLoc.city } : prev));
    const stored = getStoredUser();
    if (stored) setStoredUser({ ...stored, city: newLoc.city });

    api.users.updateLocation(p.coords.lng, p.coords.lat, newLoc.city)
      .catch(e => console.warn('Failed to update backend location via search', e));
  }, []);

  const resetLocation = useCallback(() => {
    if (gps) {
      setLocation({ ...gps, status: 'granted', custom: false });
      if (gps.coords) {
        api.users.updateLocation(gps.coords.lng, gps.coords.lat, gps.city).catch(e => console.warn('Failed to reset backend location', e));
      }
    } else {
      requestLocation();
    }
  }, [gps, requestLocation]);

  // NEW: Set location based on Pakistan city selection - map opens centered on selected city
  const setLocationFromCity = useCallback((cityName: string) => {
    const coords = getCityCoords(cityName);
    const cityInfo = getCityByName(cityName);
    if (coords && cityInfo) {
      const newLoc: Loc = {
        status: 'granted',
        coords,
        address: `${cityInfo.name}, ${cityInfo.region}`,
        city: cityInfo.name,
        region: cityInfo.region,
        accuracy: null,
        custom: true,
      };
      setLocation(newLoc);
      console.log(`[Location] Set from city ${cityName} ->`, coords);
      // Post-Audit P3: sync user.city in state + same atomic PATCH (coords+city together)
      setUser(prev => (prev ? { ...prev, city: cityInfo.name } : prev));
      const stored = getStoredUser();
      if (stored) setStoredUser({ ...stored, city: cityInfo.name });
      api.users.updateLocation(coords.lng, coords.lat, cityInfo.name).catch(e => console.warn('Failed to update backend city location', e));
      return true;
    }
    console.warn(`[Location] City not found: ${cityName}`);
    return false;
  }, []);

  // --- Auth ---
  const handleLogout = useCallback(() => {
    // Real revocation (2026-08-21): delete this device's refresh session server-side.
    // Fire-and-forget - local teardown must not depend on network success.
    try { const rt = getRefreshToken(); if (rt) api.auth.logout(rt).catch(() => {}); } catch {}
    clearAuth();
    socketClient.disconnect();
    setUser(null);
    setJobs([]);
    setMessages({});
    setNearbyRequests([]);
    setMyOffers([]);
    try { localStorage.removeItem(MY_OFFERS_KEY); } catch {}
    setActiveJobId(null);
    setActiveRequestId(null);
    persistActiveRequestId(null);
    setStack([]);
    setTabState('home');
    setStage('auth');
    setNotifications([]);
    setUnreadCount(0);
    showToast('Logged out', 'info');
  }, [persistActiveRequestId]);

  const logout = useCallback(() => {
    handleLogout();
  }, [handleLogout]);

  // completeAuth kept for compatibility but now sets user from real backend and connects socket
  const completeAuth = useCallback((role: Role, name: string, phone: string, city?: string) => {
    // This is called after successful OTP verification in onboarding which already has token
    // For compatibility, we just set user and go to appropriate stage
    // Real auth flow is handled via login methods below, but we keep this for existing calls
    const storedUser = getStoredUser();
    if (storedUser) {
      const frontendUser = adaptBackendUserToFrontendUser(storedUser);
      setUser(frontendUser);
    } else {
      // Fallback mock user if no stored user (should not happen in real flow)
      const newUser: User = {
        id: 'me',
        name,
        phone,
        city,
        role,
        avatar: name.split(' ').map(p => p[0]).slice(0, 2).join('').toUpperCase(),
        color: role === 'provider' ? '#167a6c' : '#0d8cd0',
        rating: 4.8,
        reviews: 23,
        isOnline: true,
      };
      setUser(newUser);
    }

    // 2026-08-21: route STRICTLY on the backend's setupComplete/setupStep flags (stored
    // with the user above) - identical behavior for phone OTP and Google sign-in. Gone is
    // the old infer-from-missing-category heuristic that wrongly re-onboarded RETURNING
    // providers (auth responses used to omit category, so it always looked "incomplete").
    const su = getStoredUser();
    if (su && su.setupComplete === false && role === 'provider') {
      // Partial provider signup (either method): resume at the first incomplete wizard step
      try { localStorage.setItem('ufix_setup_resume_step', su.setupStep === 'verification' ? '2' : '0'); } catch {}
      setStage('providerSetup');
    } else {
      setStage('location');
    }

    socketClient.connect();
  }, []);

  const completeProviderSetup = useCallback(async (category: Category, radiusKm: number) => {
    try {
      setLoading('providerSetup', true);
      await api.providers.setup({ category, radiusKm });
      
      // DEV: Auto-verify provider after setup to avoid manual admin step
      try {
        await api.providers.devAutoVerify();
        console.log('[ProviderSetup] Auto-verified after setup');
      } catch (e) {
        console.log('[ProviderSetup] Auto-verify after setup failed (may already be handled by backend)', e);
      }
      
      // Update local user
      setUser(prev => prev ? { ...prev, category, radiusKm, verified: true, jobsCompleted: 230, yearsExperience: 6 } : prev);
      
      // Update stored user
      const stored = getStoredUser();
      if (stored) {
        setStoredUser({ ...stored, category, radiusKm, isVerified: true, verificationStatus: 'approved' });
      }

      setStage('location');
      showToast('Profile setup completed & verified for dev', 'check');
    } catch (err: any) {
      console.error('Provider setup failed', err);
      showToast(err.message || 'Setup failed', 'info');
    } finally {
      setLoading('providerSetup', false);
    }
  }, []);

  const updateProfile = useCallback(async (name: string, city?: string) => {
    try {
      setLoading('profile', true);
      // Post-Audit Fix P4: city is editable now. Backend PATCH /api/users/profile accepts city.
      // Pre-Deploy Fix (Item 1): the `phone` parameter is GONE. The backend PATCH ignores phone
      // (login identity - changing it needs a full re-verification flow, out of scope), and the
      // old code worse than ignored it: it wrote the typed phone into local state + storedUser,
      // so the UI displayed a number the backend never saved - a true silent desync until reload.
      const cityTrimmed = city?.trim();
      const willChangeCity = !!cityTrimmed && cityTrimmed !== user?.city;
      await api.users.updateProfile(willChangeCity ? { name, city: cityTrimmed } : { name });
      setUser(prev => prev ? {
        ...prev,
        name,
        ...(willChangeCity ? { city: cityTrimmed } : {}),
        avatar: name.split(' ').map(p => p[0]).slice(0, 2).join('').toUpperCase()
      } : prev);

      const stored = getStoredUser();
      if (stored) {
        setStoredUser({ ...stored, name, ...(willChangeCity ? { city: cityTrimmed } : {}) });
      }

      // City change => move the map + stored coordinates in ONE atomic location PATCH (P3 pattern),
      // so matching immediately follows the new city after reload.
      if (willChangeCity) {
        const coords = getCityCoords(cityTrimmed!);
        const cityInfo = getCityByName(cityTrimmed!);
        if (coords && cityInfo) {
          setLocation({
            status: 'granted',
            coords,
            address: `${cityInfo.name}, ${cityInfo.region}`,
            city: cityInfo.name,
            region: cityInfo.region,
            accuracy: null,
            custom: true,
          });
          api.users.updateLocation(coords.lng, coords.lat, cityInfo.name)
            .catch(e => console.warn('Failed to move backend location after city change', e));
        }
      }

      showToast('Profile updated', 'check');
    } catch (err: any) {
      console.error('Update profile failed', err);
      showToast(err.message || 'Update failed', 'info');
    } finally {
      setLoading('profile', false);
    }
  }, [user]);

  // Pre-Deploy Fix (Item 2): wire the EXISTING POST /users/profile/picture endpoint to UI.
  // Updates user + storedUser so the photo renders via Avatar's optional `src` everywhere
  // we pass it; initials stay the fallback (mock Cloudinary URLs in dev return dummy URLs,
  // so Avatar hides broken images via onError -> initials).
  const uploadProfilePicture = useCallback(async (file: File) => {
    try {
      setLoading('picture', true);
      const res = await api.users.uploadPicture(file);
      const url = res?.profilePicture || res?.user?.profilePicture;
      if (!url) throw new Error('Upload succeeded but no picture URL returned');
      setUser(prev => (prev ? { ...prev, profilePicture: url } : prev));
      const stored = getStoredUser();
      if (stored) setStoredUser({ ...stored, profilePicture: url });
      showToast('Profile photo updated', 'check');
      return url as string;
    } catch (err: any) {
      console.error('Profile picture upload failed', err);
      showToast(err.message || 'Photo upload failed', 'info');
      return null;
    } finally {
      setLoading('picture', false);
    }
  }, [showToast]);

  const toggleOnline = useCallback(async () => {
    if (!user) return;

    const newOnlineStatus = !user.isOnline;
    
    // Optimistic update
    setUser(prev => prev ? { ...prev, isOnline: newOnlineStatus } : prev);

    try {
      // Backend fix: PATCH /api/users/profile now accepts isOnline boolean
      await api.users.updateProfile({ isOnline: newOnlineStatus } as any);
      
      const stored = getStoredUser();
      if (stored) {
        setStoredUser({ ...stored, isOnline: newOnlineStatus });
      }

      showToast(newOnlineStatus ? "You're online" : "You're offline", newOnlineStatus ? 'check' : 'info');
    } catch (err: any) {
      console.error('Toggle online failed', err);
      // Revert optimistic update
      setUser(prev => prev ? { ...prev, isOnline: !newOnlineStatus } : prev);
      showToast(err.message || 'Failed to toggle online status', 'info');
    }
  }, [user]);

  // --- Navigation ---
  const setTab = useCallback((t: Tab) => {
    setTabState(t);
    setStack([]);
  }, []);

  const navigate = useCallback((s: Screen) => setStack(prev => [...prev, s]), []);
  const back = useCallback(() => setStack(prev => prev.slice(0, -1)), []);

  // --- Customer actions - REAL BACKEND - 100% FIXED ---
  const postRequest = useCallback(async (category: Category, description: string, pin: GeoPoint, address: string) => {
    try {
      setLoading('postRequest', true);

      const baseCoords = location.coords || DEFAULT_COORDS;
      const latLng = offsetToCoords(pin.x, pin.y, baseCoords);

      console.log('[postRequest] pin:', pin, 'baseCoords:', baseCoords, '-> latLng:', latLng);

      const response = await api.requests.create({
        category,
        description,
        lng: latLng.lng,
        lat: latLng.lat,
        address,
        city: location.city || user?.city || undefined,
      });

      const backendRequest = response.request;
      const frontendJob = adaptBackendRequestToFrontendJob(backendRequest, { baseCoords: baseCoords });

      setJobs(prev => [frontendJob, ...prev]);
      setActiveRequestId(frontendJob.id);
      persistActiveRequestId(frontendJob.id); // Persist for refresh survival
      // Seed the live "X providers viewing" count from the create response (socket echo may arrive first)
      if ((backendRequest as any)?.viewingProviders) {
        const vp = (backendRequest as any).viewingProviders;
        setViewCounts(prev => ({ ...prev, [frontendJob.id]: { count: Number(vp.count) || 0, category: vp.category || category } }));
      }
      // BUG FIX (2026-08-23 — "customer sees an offer before any provider sends one"):
      // root cause was THIS line's previous target 'availableProviders' — that screen renders
      // full provider cards (avatar + stars + "PKR <profile default>" + Book Now) that are
      // visually identical to an offer card, priced from the provider's PROFILE default, so
      // right after posting the customer appeared to already have a priced offer. Live trace
      // proved the backend is clean (GET offers empty, no offer:new until a real POST), so
      // the fix is to land on the OFFERS waiting screen instead — which waits correctly at
      // zero cards with the live viewing pill until a provider explicitly submits an offer.
      // Direct booking stays reachable as an EXPLICIT choice (Jobs tab "Providers" button).
      setStack(['offers']); // land on the offers/waiting screen — zero cards until a real offer

      showToast(`Request posted in ${location.city || user?.city || 'your city'}! Finding ${category} pros...`, 'check');
      console.log(`[postRequest] Created request ${frontendJob.id} in city ${location.city}, navigating to offers waiting screen`);
    } catch (err: any) {
      console.error('Post request failed', err);
      showToast(err.message || 'Failed to post request', 'info');
    } finally {
      setLoading('postRequest', false);
    }
  }, [location.coords, persistActiveRequestId]);

  const acceptOffer = useCallback(async (jobId: string, offer: Offer) => {
    try {
      setLoading('acceptOffer', true);

      console.log(`[acceptOffer] Accepting offer ${offer.id} for request ${jobId}`);

      const response = await api.offers.accept(offer.id);

      console.log(`[acceptOffer] Response:`, response);

      const acceptedJobId = response.job?.id || response.job?._id || jobId;
      
      showToast(`${offer.providerName} is on the way`, 'check');

      // Refresh jobs to get new active job
      await refreshJobs();

      // Set active job and clear active request
      setViewCounts(prev => { const next = { ...prev }; delete next[jobId]; return next; }); // request settled - stop "viewing" pill
      setActiveJobId(acceptedJobId.toString());
      setActiveRequestId(null);
      persistActiveRequestId(null);
      setStack(['activeJob']);
      setTabState('jobs');
      // Booking confirmation tone at the exact accept-success moment.
      playBookingConfirmedTone(String(offer.id ?? '')); // deduped with socket path by offerId

      console.log(`[acceptOffer] Set activeJobId to ${acceptedJobId}, navigated to activeJob`);
    } catch (err: any) {
      console.error('Accept offer failed', err);
      showToast(err.message || 'Failed to accept offer', 'info');
    } finally {
      setLoading('acceptOffer', false);
    }
  }, [persistActiveRequestId]);

  const declineOffer = useCallback(async (jobId: string, offerId: string) => {
    // Bidirectional Sync (Part C): REAL backend decline now - PATCH /api/offers/:id/decline
    // Customer declines ONE offer; request stays open so they can accept a different offer later,
    // and the specific provider is notified (offer:declined socket + persisted offer_declined notification).
    try {
      setLoading('declineOffer', true);
      await api.offers.decline(offerId);
      // Remove locally on success - the request remains open with other offers
      setJobs(prev => prev.map(j => j.id === jobId ? { ...j, offers: j.offers.filter(o => o.id !== offerId) } : j));
      showToast('Offer declined — request stays open for other offers', 'info');
    } catch (err: any) {
      console.error('Decline offer failed', err);
      showToast(err.message || 'Failed to decline offer', 'info');
    } finally {
      setLoading('declineOffer', false);
    }
  }, []);

  // Provider withdraws their OWN pending offer (2026-08-21) - mirror of declineOffer,
  // opposite direction (provider-initiated). On success the "Your offers" card flips to
  // the distinct "Withdrawn by you" badge; the customer gets offer:withdrawn live (see the
  // socket setup) so the offer disappears from their list WITH an explanation.
  const withdrawOffer = useCallback(async (offerId: string) => {
    try {
      setLoading('withdrawOffer', true);
      await api.offers.withdraw(offerId);
      markMyOffers({ offerId }, 'withdrawn');
      showToast('Offer withdrawn — the customer has been notified', 'info');
      return true;
    } catch (err: any) {
      console.error('Withdraw offer failed', err);
      showToast(err.message || 'Failed to withdraw offer', 'info');
      return false;
    } finally {
      setLoading('withdrawOffer', false);
    }
  }, [markMyOffers, showToast]);

  const cancelRequest = useCallback(async (jobId: string) => {
    try {
      setLoading('cancelRequest', true);
      await api.requests.cancel(jobId);

      setViewCounts(prev => { const next = { ...prev }; delete next[jobId]; return next; });
      setJobs(prev => prev.map(j => j.id === jobId ? { ...j, status: 'cancelled' as any } : j));
      setActiveRequestId(null);
      persistActiveRequestId(null);
      setStack([]);
      setTabState('jobs');
      showToast('Request cancelled', 'info');
    } catch (err: any) {
      console.error('Cancel request failed', err);
      showToast(err.message || 'Failed to cancel', 'info');
    } finally {
      setLoading('cancelRequest', false);
    }
  }, [persistActiveRequestId]);

  /**
   * Direct booking (provider discovery model) - Bidirectional Sync (Part A fix)
   * Previously AvailableProvidersScreen dispatched a `ufix:booked` window event that NOTHING
   * listened to, leaving the customer stranded on the providers list (dead end).
   * Now the whole accept→unlock→navigate sequence lives here, mirroring acceptOffer():
   * the customer's screen immediately transitions to Active Job with provider details + phone unlocked.
   */
  const directBookRequest = useCallback(async (requestId: string, providerId: string): Promise<boolean> => {
    try {
      setLoading('directBook', true);
      const response = await api.requests.directAccept(requestId, providerId);
      const jobId = (response.job?.id || response.job?._id)?.toString();

      const providerName = response.acceptedOffer?.provider?.name || 'Provider';
      showToast(`${providerName} booked — on the way!`, 'check');

      await refreshJobs();

      if (jobId) setActiveJobId(jobId);
      setActiveRequestId(null);
      persistActiveRequestId(null);
      setStack(['activeJob']);
      setTabState('jobs');
      console.log(`[directBook] Booked provider ${providerId} -> job ${jobId}, navigated to activeJob`);
      return true;
    } catch (err: any) {
      console.error('Direct booking failed', err);
      showToast(err.message || 'Failed to book provider', 'info');
      return false;
    } finally {
      setLoading('directBook', false);
    }
  }, [persistActiveRequestId]);

  /**
   * Open the user's current active job screen (used from notifications tap).
   * Fetches the live job from the backend so it also works after a refresh,
   * when activeJobId hasn't been restored yet.
   */
  const openActiveJob = useCallback(async (): Promise<boolean> => {
    try {
      setLoading('openActiveJob', true);
      const data = await api.jobs.myActive();
      if (data?.job) {
        const frontendJob = adaptBackendJobToFrontendJob(data.job, { baseCoords: location.coords || DEFAULT_COORDS });
        setJobs(prev => {
          const exists = prev.some(j => j.id === frontendJob.id);
          return exists ? prev.map(j => j.id === frontendJob.id ? frontendJob : j) : [frontendJob, ...prev];
        });
        setActiveJobId(frontendJob.id);
        setTabState('jobs');
        setStack(['activeJob']);
        return true;
      }
      return false;
    } catch (err: any) {
      // Silent by design: callers (notification taps) fall back to the jobs tab when there is
      // no longer an active job (e.g. it was completed) - a scary toast would be wrong there.
      console.log('openActiveJob: no active job', err?.message || err);
      return false;
    } finally {
      setLoading('openActiveJob', false);
    }
  }, [location.coords]);

  /** Open the rating screen for a specific (completed) job - used by "Rate now" affordances. */
  const openJobRating = useCallback((jobId: string) => {
    setActiveJobId(jobId);
    setTabState('jobs');
    setStack(['rating']);
  }, []);

  /** Dismiss one entry from the provider's "Your offers" activity list. */
  const dismissMyOffer = useCallback((offerId: string) => {
    setMyOffers(prev => prev.filter(o => o.id !== offerId));
  }, []);

  const completeJob = useCallback(async (jobId: string, rating: number, review: string) => {
    try {
      setLoading('completeJob', true);

      // Bidirectional Sync note: this action now ONLY submits the rating (POST /api/jobs/:jobId/rate).
      // The job itself is marked complete by the PROVIDER via PATCH /api/jobs/:id/status —
      // both sides are auto-prompted to rate via the job:statusUpdate socket handler.
      // (Previously the customer had a fake "Mark as completed & rate" button that hit this while
      // the job was still in_progress, got a 400 from the backend, and silently faked completion —
      // that dead UI has been removed.)
      await api.jobs.rate(jobId, { rating, comment: review });

      // Record rating locally (hides the "Rate now" affordance on history/job cards)
      setJobs(prev => prev.map(j => j.id === jobId ? { ...j, status: 'completed' as any, rating, review } : j));
      setActiveJobId(null);
      setStack([]);
      setTabState('jobs');
      showToast('Thanks for rating! ⭐', 'check');
    } catch (err: any) {
      console.error('Rating submit failed', err);
      // Keep the user on the result state (job is already completed server-side), but tell them
      // the rating itself did not go through so they can retry from the job card later.
      setJobs(prev => prev.map(j => j.id === jobId ? { ...j, status: 'completed' as any } : j));
      setActiveJobId(null);
      setStack([]);
      setTabState('jobs');
      showToast(err.message || 'Failed to submit rating — you can retry from the job card', 'info');
    } finally {
      setLoading('completeJob', false);
    }
  }, []);

  // --- Provider actions - REAL BACKEND ---
  const sendOffer = useCallback(async (requestId: string, charge: number) => {
    try {
      setLoading('sendOffer', true);

      // Capture the request info BEFORE removing it from the list (needed for the provider's
      // "Your offers" activity card - Bidirectional Sync Part D row "Offer sent")
      const sourceRequest = nearbyRequests.find(r => r.id === requestId);

      // Find request to get its details for ETA calculation? Use default ETA 15
      const response = await api.offers.create(requestId, { visitingCharge: charge, etaMinutes: 15 });

      // Track own offer with live-fate badge (updated later by socket events)
      const sentOfferId = (response.offer?.id || response.offer?._id)?.toString();
      if (sentOfferId) {
        setMyOffers(prev => {
          const withoutDup = prev.filter(o => o.id !== sentOfferId);
          return [{
            id: sentOfferId,
            requestId,
            category: (sourceRequest?.category || 'plumber') as Category,
            description: sourceRequest?.description || 'Service request',
            address: sourceRequest?.address || '',
            city: (sourceRequest as any)?.city,
            visitingCharge: charge,
            etaMin: 15,
            status: 'pending' as SentOfferStatus,
            createdAt: Date.now(),
          }, ...withoutDup].slice(0, 30);
        });
      }

      // Remove from nearbyRequests
      setNearbyRequests(prev => prev.filter(r => r.id !== requestId));

      // Show toast, but don't create job yet - job will be created when customer accepts
      // For provider UX, we can optimistically show that offer sent
      showToast(`Offer of PKR ${charge} sent — track it in "Your offers"`, 'send');

      // Note: In real flow, job will be created on acceptance via socket offer:accepted event
      // That event will trigger refreshJobs and navigate to activeJob
    } catch (err: any) {
      console.error('Send offer failed', err);
      // Availability lock: backend rejected because the provider is busy - latch the busy state
      // so the banner shows and cards stay hidden without another fetch
      if (err?.data?.hasActiveJob || (err?.message || '').toLowerCase().includes('active job')) {
        setProviderBusy(true);
        setNearbyRequests([]);
      }
      showToast(err.message || 'Failed to send offer', 'info');
    } finally {
      setLoading('sendOffer', false);
    }
  }, [nearbyRequests]);

  const updateJobStatus = useCallback(async (jobId: string, status: JobStatus) => {
    try {
      setLoading('updateJobStatus', true);

      // Map frontend JobStatus to backend Job status (on_the_way, arrived, in_progress, completed)
      // Frontend has statuses: open, accepted, on_the_way, arrived, in_progress, completed, cancelled
      // Backend Job has: on_the_way, arrived, in_progress, completed
      // For provider advancing, we use the same status names for on_the_way, arrived, in_progress, completed
      // So we can pass status directly if it's one of the backend Job statuses
      const backendStatus = status as any;

      await api.jobs.updateStatus(jobId, backendStatus);

      // Optimistic update
      setJobs(prev => prev.map(j => j.id === jobId ? { ...j, status } : j));

      if (status === 'completed') {
        // Bidirectional Sync (Part B): provider gets a clear completion confirmation on their
        // own side and is taken straight to THEIR rating prompt for the customer (Phase 8
        // supports both directions). The job:statusUpdate socket handler mirrors this for the
        // customer side; both paths converge on the Rating screen idempotently.
        showToast('Job completed! 🎉 Rate your customer', 'check');
        playNotificationTone(); // actor gets no self-notification - ping here
        vibrateAlert('positive');
        setActiveJobId(jobId);
        setTabState('jobs');
        setStack(['rating']);
      } else {
        showToast(`Status updated to ${status.replace('_', ' ')}`, 'check');
      }
    } catch (err: any) {
      console.error('Update job status failed', err);
      showToast(err.message || 'Failed to update status', 'info');
    } finally {
      setLoading('updateJobStatus', false);
    }
  }, []);

  // --- Chat - REAL BACKEND via Socket ---
  const openChat = useCallback(async (jobId: string) => {
    setActiveJobId(jobId);
    
    try {
      setLoading('chatHistory', true);
      
      // Fetch chat history via REST
      const historyData = await api.messages.history(jobId);
      const backendMessages = historyData.messages || [];
      
      // Adapt to frontend ChatMessage
      const currentUserId = user?.id;
      const adaptedMessages: ChatMessage[] = backendMessages.map((msg: any) => {
        const adapted = adaptBackendMessageToFrontendMessage(msg, { currentUserId });
        return {
          id: adapted.id,
          senderId: adapted.senderId === currentUserId ? 'me' : adapted.senderId,
          text: adapted.text,
          timestamp: adapted.timestamp,
          read: adapted.read,
        };
      });

      setMessages(prev => ({
        ...prev,
        [jobId]: adaptedMessages,
      }));

      // Mark as read via socket
      socketClient.markChatRead(jobId);

    } catch (err: any) {
      console.error('Failed to load chat history', err);
      showToast('Failed to load chat history', 'info');
    } finally {
      setLoading('chatHistory', false);
    }

    navigate('chat');
  }, [user?.id]);

  const markRead = useCallback((jobId: string, senderId: string) => {
    // This is called from chat screen when opening, to mark messages from peer as read
    // In real backend, we use socket chat:markRead which marks all unread NOT sent by requester as read
    // The senderId param here is peer id, but we ignore it and just mark all unread from other party as read
    socketClient.markChatRead(jobId);

    // Optimistic update locally
    setMessages(prev => {
      const list = prev[jobId] ?? [];
      return {
        ...prev,
        [jobId]: list.map(m => m.senderId === senderId ? { ...m, read: true } : m),
      };
    });
  }, []);

  const sendMessage = useCallback((jobId: string, text: string, peer: { id: string; isProvider: boolean }) => {
    const trimmed = text.trim();
    if (!trimmed) return;

    // Optimistic update: add message as "me" immediately
    const tempId = `temp-${Date.now()}`;
    const optimisticMessage: ChatMessage = {
      id: tempId,
      senderId: 'me',
      text: trimmed,
      timestamp: Date.now(),
      read: false,
    };

    setMessages(prev => {
      const list = prev[jobId] ?? [];
      return {
        ...prev,
        [jobId]: [...list, optimisticMessage],
      };
    });

    // Send via socket
    socketClient.sendChatMessage(jobId, trimmed, (response: any) => {
      if (response?.status === 'error') {
        console.error('Failed to send message via socket', response.error);
        showToast(response.error?.message || 'Failed to send message', 'info');
        // Remove optimistic message on failure
        setMessages(prev => {
          const list = prev[jobId] ?? [];
          return {
            ...prev,
            [jobId]: list.filter(m => m.id !== tempId),
          };
        });
      } else if (response?.status === 'success' && response.message) {
        // Server returns adapted message, replace temp optimistic with real
        const realMessageData = response.message;
        const realChatMessage: ChatMessage = {
          id: realMessageData.id,
          senderId: 'me', // since we sent it, it's me
          text: realMessageData.text,
          timestamp: realMessageData.timestamp,
          read: realMessageData.read || false,
        };

        setMessages(prev => {
          const list = prev[jobId] ?? [];
          return {
            ...prev,
            [jobId]: list.map(m => m.id === tempId ? realChatMessage : m),
          };
        });
      }
    });
  }, []);

  // --- Notifications - REAL BACKEND ---
  const loadNotifications = useCallback(async () => {
    try {
      setNotificationsLoading(true);
      const data = await api.notifications.list({ page: 1, limit: 20 });
      const backendNotifs = data.notifications || [];
      const adapted = backendNotifs.map((n: any) => adaptBackendNotificationToFrontend(n));
      setNotifications(adapted);
      setUnreadCount(data.unreadCount ?? data.pagination?.unreadCount ?? 0);
    } catch (err: any) {
      console.error('Failed to load notifications', err);
    } finally {
      setNotificationsLoading(false);
    }
  }, []);

  const markNotificationRead = useCallback(async (id: string) => {
    try {
      await api.notifications.markRead(id);
      setNotifications(prev => prev.map(n => n.id === id ? { ...n, isRead: true } : n));
      setUnreadCount(prev => Math.max(0, prev - 1));
    } catch (err: any) {
      console.error('Failed to mark notification read', err);
    }
  }, []);

  const markAllNotificationsRead = useCallback(async () => {
    try {
      await api.notifications.markAllRead();
      setNotifications(prev => prev.map(n => ({ ...n, isRead: true })));
      setUnreadCount(0);
    } catch (err: any) {
      console.error('Failed to mark all read', err);
    }
  }, []);

  // --- Refresh functions ---
  const refreshNearbyRequests = useCallback(async (opts?: { silent?: boolean }) => {
    if (user?.role !== 'provider') return;
    // 2026-08-22 flicker fix: background 5s polls are SILENT. Only manual refreshes (and the
    // first load) show the skeleton; before this, every poll swapped the card list for
    // skeletons, unmounting every card -> entrance animation re-triggered (blinking) AND
    // the in-progress edited price input reset to the base price (hidden-cause of BUG 2).
    const silent = !!opts?.silent;

    try {
      if (!silent) setLoading('nearbyRequests', true);
      const data = await api.requests.nearby();
      const backendRequests = data.requests || [];

      // Availability lock: backend hides nearby requests for busy providers and flags it.
      // Sync the flag so the banner shows + cards stay hidden; clears automatically when free.
      setProviderBusy(!!data.hasActiveJob);

      console.log(`[refreshNearbyRequests] Found ${backendRequests.length} nearby requests (busy=${!!data.hasActiveJob})`, data.providerLocation);

      const adapted: IncomingRequest[] = backendRequests.map((req: any) =>
        adaptBackendRequestToIncomingRequest(req, { baseCoords: location.coords || DEFAULT_COORDS })
      );

      // Render stability: identical content -> identical array reference (no re-render at
      // all); otherwise unchanged cards keep their previous object identity so a live-distance
      // number updates WITHOUT the whole card re-flashing or losing input state.
      setNearbyRequests(prev => reconcileNearbyRequests(prev, adapted));
    } catch (err: any) {
      console.error('Failed to refresh nearby requests', err);
      const msg = err.message || '';
      if (msg.toLowerCase().includes('verified')) {
        showToast('Auto-verifying for dev...', 'info');
        // DEV FIX: Auto-verify provider then retry
        try {
          console.log('[refreshNearbyRequests] Verification needed, calling dev auto-verify...');
          await api.providers.devAutoVerify();
          console.log('[refreshNearbyRequests] Auto-verified, retrying nearby...');
          const retryData = await api.requests.nearby();
          const retryRequests = retryData.requests || [];
          setProviderBusy(!!retryData.hasActiveJob);
          console.log(`[refreshNearbyRequests] After auto-verify found ${retryRequests.length} requests`);
          const adapted: IncomingRequest[] = retryRequests.map((req: any) => 
            adaptBackendRequestToIncomingRequest(req, { baseCoords: location.coords || DEFAULT_COORDS })
          );
          setNearbyRequests(adapted);
          // Update user state
          setUser(prev => prev ? { ...prev, verified: true, isVerified: true } as any : prev);
          showToast('Verified! Now you can receive requests', 'check');
        } catch (verifyErr) {
          console.error('Auto-verify failed', verifyErr);
          showToast('Provider not verified - auto-verify failed, trying anyway', 'info');
          // Even if auto-verify endpoint fails (maybe already handled by backend auto-verify in getNearbyRequests), try one more time
          try {
            const retry2 = await api.requests.nearby();
            const retryRequests2 = retry2.requests || [];
            setProviderBusy(!!retry2.hasActiveJob);
            const adapted2: IncomingRequest[] = retryRequests2.map((req: any) => 
              adaptBackendRequestToIncomingRequest(req, { baseCoords: location.coords || DEFAULT_COORDS })
            );
            setNearbyRequests(adapted2);
          } catch {}
        }
      } else if (msg.toLowerCase().includes('location')) {
        showToast('Location not set - fixing to Faisalabad default...', 'info');
        // Auto-fix: set default location in backend + retry once
        try {
          await api.users.updateLocation(DEFAULT_COORDS.lng, DEFAULT_COORDS.lat);
          console.log('[refreshNearbyRequests] Auto-fixed location to DEFAULT_COORDS, retrying...');
          // Retry after fix
          const retryData = await api.requests.nearby();
          const retryRequests = retryData.requests || [];
          setProviderBusy(!!retryData.hasActiveJob);
          console.log(`[refreshNearbyRequests] Retry found ${retryRequests.length} requests`);
          const adapted: IncomingRequest[] = retryRequests.map((req: any) => 
            adaptBackendRequestToIncomingRequest(req, { baseCoords: location.coords || DEFAULT_COORDS })
          );
          setNearbyRequests(adapted);
          if (retryRequests.length > 0) {
            showToast(`Fixed! Found ${retryRequests.length} requests`, 'check');
          }
        } catch (retryErr) {
          console.error('Retry after location fix failed', retryErr);
        }
      } else if (msg.toLowerCase().includes('category')) {
        showToast('Complete provider setup first', 'info');
      }
    } finally {
      if (!silent) setLoading('nearbyRequests', false);
    }
  }, [user?.role, location.coords]);

  const refreshJobs = useCallback(async () => {
    try {
      setLoading('jobs', true);

      if (user?.role === 'customer') {
        // For customer, fetch my requests
        const data = await api.requests.my();
        const backendRequests = data.requests || [];
        
        const adaptedJobs: Job[] = backendRequests.map((req: any) => 
          adaptBackendRequestToFrontendJob(req, { baseCoords: location.coords || DEFAULT_COORDS })
        );

        // 100% FIX: Auto-restore activeRequestId if null but open request exists (survives refresh)
        const persistedId = getPersistedActiveRequestId();
        const openRequest = adaptedJobs.find(j => (j as any)._originalStatus === 'pending' || (j as any).status === 'open' || (j as any).status === 'accepted');
        const latestOpen = adaptedJobs.filter(j => (j as any)._originalStatus === 'pending' || (j as any).status === 'open').sort((a,b)=> b.createdAt - a.createdAt)[0];

        if (!activeRequestId) {
          if (persistedId && adaptedJobs.some(j => j.id === persistedId)) {
            console.log(`[refreshJobs] Restoring activeRequestId from localStorage: ${persistedId}`);
            setActiveRequestId(persistedId);
          } else if (latestOpen) {
            console.log(`[refreshJobs] Setting activeRequestId to latest open request: ${latestOpen.id}`);
            setActiveRequestId(latestOpen.id);
            persistActiveRequestId(latestOpen.id);
          }
        }

        // Also fetch active job if any
        try {
          const activeData = await api.jobs.myActive();
          if (activeData.job) {
            const activeJobAdapted = adaptBackendJobToFrontendJob(activeData.job, { baseCoords: location.coords || DEFAULT_COORDS });
            // Replace or add active job to list, avoid duplicates
            const existingIndex = adaptedJobs.findIndex(j => j.id === activeJobAdapted.id);
            if (existingIndex >= 0) {
              adaptedJobs[existingIndex] = activeJobAdapted;
            } else {
              adaptedJobs.unshift(activeJobAdapted);
            }
            // If active job exists, set as activeJobId and clear request id if needed
            if (!activeJobId) {
              setActiveJobId(activeJobAdapted.id);
              console.log(`[refreshJobs] Set activeJobId to active job: ${activeJobAdapted.id}`);
            }
          }
        } catch (e) {
          // No active job, ok
        }

        setJobs(adaptedJobs);
      } else if (user?.role === 'provider') {
        // For provider, fetch active job + history
        let allJobs: Job[] = [];

        try {
          const activeData = await api.jobs.myActive();
          if (activeData.job) {
            const activeJobAdapted = adaptBackendJobToFrontendJob(activeData.job, { baseCoords: location.coords || DEFAULT_COORDS });
            allJobs.push(activeJobAdapted);
          }
        } catch (e) {
          // No active job
        }

        try {
          const historyData = await api.jobs.history({ status: 'all' as any, page: 1, limit: 50 });
          const history = historyData.history || [];
          // history contains both jobs and cancelled requests merged
          // Map cancelled requests to Job shape for display in JobsTab
          const historyJobs: Job[] = history.map((item: any) => {
            if (item.type === 'job') {
              // Already a job, adapt if needed
              const backendJob = item; // item has id, status, category, etc.
              // If item has frontend field, use it, else adapt
              if (item.frontend) {
                return item.frontend;
              }
              // Simple mapping for history job
              return {
                id: item.id.toString(),
                customerId: item.customer?.id || item.customer?.toString() || 'unknown',
                customerName: item.customer?.name || 'Customer',
                category: item.category,
                description: item.description,
                location: item.location ? (() => {
                  const [lng, lat] = item.location.coordinates;
                  const xy = lngLatToXY(lng, lat, location.coords || DEFAULT_COORDS);
                  return { x: xy.x, y: xy.y, label: item.address || '' };
                })() : { x: 50, y: 50, label: 'Location' },
                address: item.address || '',
                status: item.status,
                createdAt: toTimestamp(item.createdAt || item.completedAt),
                offers: [],
              } as Job;
            } else {
              // Cancelled request
              const [lng, lat] = item.location?.coordinates || [73.0776, 31.4181];
              const xy = lngLatToXY(lng, lat, location.coords || DEFAULT_COORDS);
              return {
                id: item.id.toString(),
                customerId: user.id,
                customerName: user.name,
                category: item.category,
                description: item.description,
                location: { x: xy.x, y: xy.y, label: item.address || '' },
                address: item.address || '',
                status: 'cancelled' as any,
                createdAt: toTimestamp(item.createdAt),
                offers: [],
              } as Job;
            }
          });

          // Merge with active job, avoid duplicates
          const jobIds = new Set(allJobs.map(j => j.id));
          historyJobs.forEach(j => {
            if (!jobIds.has(j.id)) {
              allJobs.push(j);
            }
          });
        } catch (e) {
          console.warn('Failed to fetch history', e);
        }

        setJobs(allJobs);
      }
    } catch (err: any) {
      console.error('Failed to refresh jobs', err);
    } finally {
      setLoading('jobs', false);
    }
  }, [user?.role, user?.id, location.coords]);

  // Load notifications on mount when app stage
  useEffect(() => {
    if (stage === 'app' && user) {
      loadNotifications();
      refreshJobs();
      if (user.role === 'provider') {
        refreshNearbyRequests();
      }
    }
  }, [stage, user, loadNotifications, refreshJobs, refreshNearbyRequests]);

  // Also refresh jobs when tab changes to jobs
  useEffect(() => {
    if (stage === 'app' && tab === 'jobs' && user) {
      refreshJobs();
    }
  }, [tab, stage, user, refreshJobs]);

  // Derived activeJob from jobs + activeJobId
  const activeJob = jobs.find(j => j.id === activeJobId) || null;

  const value: AppContextValue = {
    stage,
    setStage,
    user,
    tab,
    screen: stack[stack.length - 1] ?? null,
    jobs,
    nearbyRequests,
    messages,
    activeRequestId,
    activeJobId,
    activeJob,
    toast,
    draftCategory,
    setDraftCategory,
    location,
    gps,
    requestLocation,
    skipLocation,
    searchLocation,
    resetLocation,
    setLocationFromCity,
    completeAuth,
    completeProviderSetup,
    updateProfile,
    uploadProfilePicture,
    toggleOnline,
    logout,
    setTab,
    navigate,
    back,
    postRequest,
    acceptOffer,
    declineOffer,
    withdrawOffer,
    cancelRequest,
    directBookRequest,
    openActiveJob,
    openJobRating,
    dismissMyOffer,
    completeJob,
    myOffers,
    providerBusy,
    viewCounts,
    sendOffer,
    updateJobStatus,
    openChat,
    markRead,
    sendMessage,
    notifications,
    unreadCount,
    notificationsLoading,
    loadNotifications,
    markNotificationRead,
    markAllNotificationsRead,
    refreshNearbyRequests,
    refreshJobs,
    isLoading,
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useApp must be used within AppProvider");
  return ctx;
}
